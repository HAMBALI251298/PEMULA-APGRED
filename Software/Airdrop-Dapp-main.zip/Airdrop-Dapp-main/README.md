# Airdrop
Create Your Token Airdrop and Collect Some Money, Increase your token holders by distributing small amount from your token to 1000's of holders, also you can collect fees.

Video tutorial: https://www.youtube.com/watch?v=m92ARWf1o1g

Follow this steps:

1- create airdrop contract: https://0xfactory.com/airdrop-contract 

2- choose your preferred theme (dark or light)

Dark demo: https://airdrop.0xfactory.com

Light demo: https://airdrop-light.0xfactory.com

3- edit the file "data.json" using any text editor and save

4- upload all the files to your hosting

That is all....

Good luck
