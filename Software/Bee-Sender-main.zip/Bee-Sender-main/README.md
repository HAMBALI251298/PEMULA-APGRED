# Bee-Sender-v2
Bee Sender v2-ERC20 Token Airdrop Multi Sender.Packer your multi transfer in one transaction and save your cost.<br>

``Batch Send Token``<br>
``Batch Send ETH/BNB/Matic...``<br>
Current support Blockchain networks:<br>
Ethereum,Binance,Huobi,Fantom,Polygon and Ropsten testnetwork.<br><br>
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/1.png" width="25" height="25" alt="eth"> 
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/56.png" width="25" height="25" alt="bnb">
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/250.png" width="25" height="25" alt="ftm">
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/137.png" width="25" height="25" alt="matic"> 
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/43114.png" width="25" height="25" alt="matic">
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/25.png" width="25" height="25" alt="matic">
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/13381.png" width="25" height="25" alt="matic">
<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/img/534.png" width="25" height="25" alt="matic">
<br>
V2 add features:<br>
1.Sending tokens with decimal points is now supported,like:1.01,2.3,33 is accept.<br>
2.Supports importing addresses and sending quantities using CSV files.<br>
3.If you want to fork Bee Sender to earn cryptocurrency, version 2 removes the fee limit, and now you can customize the user fee. High or low is up to you.<br>
4.upgrade GUI.<br>
5.add Ethereum network.<br>

Send addresses once:<br>
1-500<br>

<img src="https://github.com/AlgoCryptoDapp/Bee-Sender/blob/main/screen.png" alt="erc20-tokens-multi-sender">

Site1:
https://AlgoCryptoDapp.github.io/Bee-Sender/

Site2:
https://dapp404.com/Bee-Sender


# Need Earn cryptocurrency?
Open js/config.js<br>
Change the address to your own address,customize fee you will recieve.<br>


# Deploy to github page
https://github.com/AlgoCryptoDapp/Page<br>

or you can download source ,and put to any web server.then start earn cryptocurrency!<br>

# You can deployed this source to any server and change the brand name without my approve.

<br>
Update:<br>
Version 2.1:Fix bug,add multi language.<br>
